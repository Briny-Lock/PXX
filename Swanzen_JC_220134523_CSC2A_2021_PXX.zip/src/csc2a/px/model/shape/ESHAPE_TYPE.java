/**
 * 
 */
package csc2a.px.model.shape;

/**
 * @author JC Swanzen (220134523)
 * @version PX
 *
 */
public enum ESHAPE_TYPE {
	LINE,
	CIRCLE,
	RECTANGLE,
	TRIANGLE,
	CARRIAGE_SHAPE,
	POLYGON
}
