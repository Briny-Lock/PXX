package csc2a.px.model.game;

/**
 * @author JC Swanzen (220134523)
 * @version PXX
 *
 */
public enum EGAME_STATE {
	CONTINUE,
	WIN,
	LOSE
}
